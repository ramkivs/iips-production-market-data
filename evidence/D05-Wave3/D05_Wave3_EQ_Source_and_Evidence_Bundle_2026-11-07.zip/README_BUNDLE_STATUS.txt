D05 WAVE-3 — NSE EQ SOURCE & EVIDENCE BUNDLE
Bundle date: 2026-11-07
Working universe: 2,390 NSE CM EQ-series records (as directed).

CONTENTS

01_source_material/
  Original source files supplied during this work: NSE Equity Master, BSE list (original and cleaned), depository ISIN details, MCA Company Master ZIP, NSE Indices classification reference, and D05 source-acquisition tools.

02_latest_prepared_candidates/
  Latest supplied versions of the taxonomy CSV, tick-size CSV, MCA face-value reconciliation, and MCA identity bridge. These are copied under clean canonical filenames; their original upload filenames/versions are represented in the conversation.

03_prior_iterations/
  Earlier supplied iterations retained for traceability only. Do not treat these as replacements for the latest prepared candidates.

IMPORTANT STATUS NOTES
- This bundle preserves supplied source material and prepared artifacts; it does not certify D05 contract acceptance or deposition.
- Latest taxonomy file is the version supplied as arena_taxonomy_submission(2).csv.
- Latest tick-size file is arena_tick_size_evidence(1).csv (2,390 EQ rows, stated uniform tickSize 0.05).
- Latest face-value reconciliation is arena_mca_face_value_reconciliation(2).csv.
- Latest MCA identity bridge is arena_mca_identity_bridged(1).csv (reported 2,296 resolved CINs and 94 unresolved).
- Prior versions are retained only for audit/traceability.
- No file contents have been modified during bundling; only archive paths and names are normalized for clarity.
