# IPD D02 — Level E Read-Only D5 / D16 Live Inventory Evidence Report

- **Generated (UTC):** `2026-11-16T14:38:20.857Z`
- **Disposition:** `INVENTORY_COMPLETE_READ_ONLY_VERIFIED` (exit code `0`)
- **Target SQLite Path:** `C:\iips-data\iips\user-portfolio.sqlite`
- **Evidence Directory:** `C:\Users\USER\AppData\Local\IIPS\d02-d5-d16-readonly-inventory\d02-d5-d16-inventory-20261116T143819255Z-96672044`
- **Operator Package Version:** `2026-11-16.1`
- **Query Catalog Source:** `docs/integration/IPD-D02-D5-D16-READ-ONLY-INVENTORY-AND-BLOCKER-REPORT-2026-11-16.md` (`2f5a7b846fb250be031808e9541d2acc366c94224b9bae5aadc85f561d9ba4da`)

## 1. Governance & Gate Separation Notice

- This artifact records **Level E strictly read-only D5 / D16 SQLite inspection evidence only** under the narrow 2026-11-16 Program Authority approval.
- **Zero mutations executed:** no application startup, no `openDatabase()`, no `ensureMigrations()`, no binding resolvers, no Direct P1 provisioning, no `npm`/`npx` installs, and no DDL/DML writes.
- **Separate gates remain closed until explicitly approved:**
  - **D5 (`D5-T1`–`D5-T5`) acceptance:** separate gate
  - **D16 detailed schema & idempotency specification approval:** separate gate
  - **Implementation authority:** separate gate
  - **Live provisioning / owner reassignment / migration execution:** separate gate
  - **D6 (`IRR` integration):** `NOT STARTED`

## 2. Read-Only Safety, Runtime & Hash Integrity Proof

| Check | Value / Result |
|---|---|
| Host platform / arch | `win32` / `x64` |
| Node.js runtime | `22.16.0` (`C:\Node22\node-v22.16.0-win-x64\node.exe`) |
| Bundled SQLite version | `3.49.1` |
| `node:sqlite` read-only API probe | `PASS` |
| PowerShell host preflight | `PASS` |
| Runner SHA-256 (`d02-d5-d16-readonly-inventory-runner.mjs`) | `7d92d11fe970a55c1fb3274e635525af8f779257487546fd4d2d63effb288f77` |
| Catalog SHA-256 (`d02-d5-d16-query-catalog.mjs`) | `484640be587c88bec90239d05fb983205125070aea3e023b4b9b35eb561002fe` |
| Combined `Q01`–`Q14` SQL SHA-256 | `af494435061555a33c289f2730d463576d6cf58c9d4f2582341e5f97bc87b937` |
| Pre-inspection DB size (bytes) | `176128` |
| Post-inspection DB size (bytes) | `176128` |
| Pre-inspection DB SHA-256 | `6d683b3b897f09156fd51bd7ba6e5cfc3a69f734a00da9f12c103da720b70673` |
| Post-inspection DB SHA-256 | `6d683b3b897f09156fd51bd7ba6e5cfc3a69f734a00da9f12c103da720b70673` |
| Exact pre/post SHA-256 equality | `true` |
| Pre-inspection sidecars (`-wal`/`-shm`/`-journal`) | `NONE (PASS)` |
| Post-inspection sidecars (`-wal`/`-shm`/`-journal`) | `NONE (PASS)` |

## 3. Query Execution Summary (`Q01`–`Q14`)

| Statement | Group | Status | Rows | SQL SHA-256 |
|---|---|---|---:|---|
| `Q01` | `Q01` | `EXECUTED_OK` | 6 | `891972b4b83cac0520b0533ccc866c7cd255044223c4a1f42d69db4c26467169` |
| `Q02` | `Q02` | `EXECUTED_OK` | 17 | `aa2447e5f56603b48565729034657b24e8b3f2cacd7d9b30e8055d74c03a4257` |
| `Q03a` | `Q03` | `EXECUTED_OK` | 1 | `190c4255f4cd4ac912d29012595c92983d4d46c5a2bf2da30daf909f75a25b27` |
| `Q03b` | `Q03` | `EXECUTED_OK` | 0 | `78390848a73c380a618898d9cc8e22f5cb3e5996bae72edd58dc46f699000f56` |
| `Q04a` | `Q04` | `EXECUTED_OK` | 1 | `0546c7fa1f8ecbb55af6a29d11c26cac0d2ce3931174ad77c7a81653f7831c2f` |
| `Q04b` | `Q04` | `EXECUTED_OK` | 1 | `e31af8eabbdaa30741fe4ebf23b8f0b2237df8f605fdbb7c11a281ea25c1a275` |
| `Q05a` | `Q05` | `EXECUTED_OK` | 1 | `0773d1034f2bf0b94f7d464a44369345d2bde2c28713dc8b73b2fbc704afc1f2` |
| `Q05b` | `Q05` | `EXECUTED_OK` | 2 | `6ede571c4b5c58da5928b93cdeaa58b6b75313509cc4e9357c5c6a5f121bd11b` |
| `Q06` | `Q06` | `EXECUTED_OK` | 3 | `79f64acd36ddc178385eccbed147611276ee6ac644b308a259e9ff5f854a35dd` |
| `Q07` | `Q07` | `EXECUTED_OK` | 13 | `5720b6fb172824192672330a4361dc21c62543e7a9c16477a0c18cede851a0f7` |
| `Q08` | `Q08` | `EXECUTED_OK` | 12 | `c335228ffd890f5a4d2c7ba269e0e790cb2da71cc3254673176e470e0afea137` |
| `Q09` | `Q09` | `EXECUTED_OK` | 6 | `7f325feef4e4b5bddfdff3ff3ea7f673addbf8c7d2ad7313055a626f251f5b03` |
| `Q10` | `Q10` | `EXECUTED_OK` | 1 | `379d78f248c1f74e71dad9249af5620326c64b5ddbccb0e3d91d29d2783fa5c1` |
| `Q11a` | `Q11` | `EXECUTED_OK` | 0 | `c947870022c81e76e90c3c3a5ff8172350f8cda7db08b48fda5c357644bcabd5` |
| `Q11b` | `Q11` | `EXECUTED_OK` | 0 | `126118ba389053e19828e5bad74c764d52dd503484c1e93b8a76ba408f1a107e` |
| `Q11c` | `Q11` | `EXECUTED_OK` | 2 | `8716fd5c839287c49d01590478c26c19229861857dd4ebf542702753820f3257` |
| `Q12a` | `Q12` | `EXECUTED_OK` | 0 | `3809c333f82264d9ba939f1908f5bcaccbec73acf0f7864dcfc123f00c20e17a` |
| `Q12b` | `Q12` | `EXECUTED_OK` | 1 | `4743e571dcfed2350b94b313ef255aa607254da2434fcbd1e833e883ad12fe96` |
| `Q12c` | `Q12` | `EXECUTED_OK` | 0 | `09741245acb79c1238267c8241b344e718af3df60bb7d58baafad82c2222d951` |
| `Q13` | `Q13` | `EXECUTED_OK` | 2 | `dc23b5859c2b34567435bb07ca13eef8519668709cc0a870f6e2cc3adfa0a04b` |
| `Q14` | `Q14` | `EXECUTED_OK` | 1 | `cfbfd45dcdf2cfb78dc3ee69d883bb44f44b824b40c51c052e952820eb09fa8a` |

## 4. Schema, Migration Ledger & Structural Integrity

- **Applied migrations in `_migration_ledger`:** `6` (all match repository checksums: `true`)
- **Missing repository migrations (`001`–`006`):** `NONE`
- **`006_portfolio_restore` applied / `portfolio_restore_receipts` present:** `true` / `true`
- **Candidate D02 tables state:** `NO_D02_LEDGER_TABLES_PRESENT`
- **`PRAGMA integrity_check` / `PRAGMA foreign_key_check`:** `ok` / `0 violations`
- **`Q14` (`PRAGMA query_only` inside snapshot):** `1 (VERIFIED)`

## 5. Principal, Portfolio, Holding, Contribution & Audit Counts

- **Active identity state:** `ACTIVE_ESTABLISHED_S1_TUPLE`
- **`local_principal_bindings`:** total `1` (`ACTIVE`: `1`, `REVOKED`: `0`)
- **`local_principal_memberships`:** total `1` (`ACTIVE`: `1`, `REVOKED`: `0`)
- **`portfolios`:** total `3` (`ACTIVE`: `2`, `TOMBSTONED`: `1`; distinct owners: `1`; distinct tenants: `1`)
  - `CANDIDATE_S1_HISTORICAL_PORTFOLIO` (`ipd-owner-ramki-personal` / `ipd-personal-local`): `3`
  - `EXISTING_D02_OWNER_PORTFOLIO` (`owner-4dc756b3` / `ipd-personal-local`): `0`
  - `UNRESOLVED_OTHER_OWNER_OR_TENANT`: `0`
- **`portfolio_revisions`:** total `13`
- **`portfolio_holdings`:** total rows across revisions `142` (active rows: `139`; `security_identity` populated: `2`; `security_identity` NULL: `140`)
- **`portfolio_contributions`:** total `6` (all `004` provenance fields populated: `4`; any `004` field NULL: `2`)
- **`portfolio_restore_receipts`:** total `1` (status: `EXECUTED_OK`)
- **`audit_events`:** total `2`, in-memory SHA-256 chain verified: `true`

## 6. Collisions, Duplicates, Orphans, NULLs & Unresolved Records

- **`Q11a` S1-vs-D02 `portfolio_id` collisions:** `0`
- **`Q11b` duplicate normalized symbols per revision:** `0`
- **`Q11c` partial-unique active binding/membership violation:** `false`
- **`Q12a` orphan / inactive-parent memberships:** `0`
- **`Q12b` `current_revision` / tombstone mismatches:** `1`
- **`Q12c` declared vs actual `holdings_count` mismatches:** `0`
- **`Q07` NULL/empty revision digests:** `2`
- **Explicitly flagged blocker unresolved records:** `1`
- **Non-inferential schema/provenance observations:** `14`

## 7. Local Sensitivity & Sharing Note

- `02-q01-q14-query-results.json` stores exact local `Q01`–`Q14` SQL rows (including `portfolios.portfolio_name`, `local_principal_bindings.principal_label`, and `audit_events.detail_json`, while `Q09` never projects raw `file_name`). Inspect `02-q01-q14-query-results.json` locally before sharing externally; `d5-d16-inventory-summary.json` and `03`–`06` JSON artifacts contain sanitized counts, structural keys, and non-inferential classifications.

